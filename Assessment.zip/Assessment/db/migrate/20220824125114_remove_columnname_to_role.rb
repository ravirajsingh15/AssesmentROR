class RemoveColumnnameToRole < ActiveRecord::Migration[7.0]
  def change
    remove_column :roles, :name, :string
  end
end
