class RemovColumnTOrole < ActiveRecord::Migration[7.0]
  def down
    remove_column :roles, :customer, :string
    rename_column :roles, :property_owner, :type, :string
  end
end
