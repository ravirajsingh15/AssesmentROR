class HomesController < ApplicationController
  def index
  end

  def dashboard
  end
  
end
