class BookingsController < ApplicationController
  def new
    @booking = Booking.new
  end

  def index
    @booking=Booking.all
  end

  def show
    @booking=Booking.find(params[:id])
  end
  def create
    @booking=Booking.new(booking_params)
    @booking.user_id=current_user.id
    respond_to do |format|
      if @booking.save
        format.html { redirect_to property_url(@booking), notice: "Booking was successfully created"}
      else
        format.html { render :new, status: :unprocessable_entity }
      end
  end

  def destroy

  end
  
  private
  def booking_params
    params.require(:booking).permit(:start_date, :end_date, :status, :price)
  end
end
end